tunnel-client（Android，arm64-v8a） v1.4.0
================================

文件
----
  tunnel-client-android-1.4.0.apk   安装包（minSdk 24 / Android 7.0+，targetSdk 34）
  README.txt               本说明

tunnel-client — 作者：wwm <szwwmz@gmail.com>

版本说明
--------
v1.4.0
  1. 与 Windows / Linux 端统一版本号 1.4.0（versionName 1.4.0 / versionCode 150）。
  2. 日志统一为英文：核心输出的级别标签为 TRACE / DEBUG / INFO / WARN / ERROR，
     状态行前缀 [STATE]；界面文案仍跟随系统语言中英双语。
  3. 作者信息更新为 wwm <szwwmz@gmail.com>。
  4. 修复 L2TP/IPsec 长域名被静默截断（IKE host 64 -> 256 字节）。

v1.3.14
  1. 合规：APK 内置第三方组件许可声明（assets/THIRD-PARTY-NOTICES.txt），
     在「关于 → 第三方组件」可查看；覆盖 Wintun、OpenSSL 3.0.2（静态链接）、
     NDK/libc++、Kotlin stdlib。
  2. 合规：全部源文件补充 SPDX 许可标识与版权头；应用图标确认为自绘原创。

v1.3.13
  1. 修复"自动重连成功后数据不通"：每次重连成功都会重新走 establish，
     用服务器新分配的地址重建 TUN。原来只在第一次连接时建隧道，重连后
     TUN 接口上仍是旧地址（日志里 10.10.5.72 → 10.10.5.68），应用发出的
     包源地址不对，服务器按会话直接丢弃，所以界面显示已连接但一个包都
     不通；手动断开再连会好，是因为那条路径顺带把旧 TUN 拆了。
  2. 进入重连态（含 4G/WiFi 切换的断网）立即拆除旧隧道，不再让旧接口
     把全系统流量吸进没人读的 TUN。

v1.3.12
  1. 修复退出 / 断开时的偶发闪退：工作线程没在超时内退出时，不再释放客户端
     对象（以前会 free 掉线程仍在使用内存，native 段错误，Java 崩溃处理器抓
     不到，表现就是"用着用着直接退出、重开什么日志都没有"）。
  2. stop/destroy 移到后台线程串行执行，主线程不再被 join 卡住（避免 ANR）。
  3. 日志落盘：每行同步写入 filesDir/session.log（超过 256KB 只保留后一半），
     进程异常退出后重开界面，日志区会自动回填上次会话最后 200 行，并带
     HH:mm:ss 时间戳；Java 崩溃时 crash.log 里同时附上崩溃前 200 行日志。
  4. 连接中/已连接时锁定所有配置项（v1.3.11 起）。

v1.3.11
  1. 连接中 / 认证中 / 已连接 / 重连中，服务器、端口、账号、密码、协议、
     证书模式、路由与 DNS 开关全部锁定（置灰不可点），断开或失败后恢复。
     这些参数只在点"连接"那一刻被读入 Service，运行期间改了也不会生效，
     以前能改容易让人误以为改完就起到了作用。

v1.3.10
  1. 流量统计修复：核心原来只在 PPP up 那一刻上报过一次统计，之后再也不发，
     界面上的收发字节/包数永远停在 0，看起来像"连接成功后应用卡死"。
     现在工作线程每秒上报一次。
  2. 日志重绘合并：高频日志（断网时的发送失败）只在主线程排一次重绘，
     不再把消息队列淹没导致界面失去响应。

v1.3.9
  1. 断网检测：Service 监听系统默认网络（ConnectivityManager
     .registerDefaultNetworkCallback）。WiFi / 移动网络断开时立即
     提示"网络已断开，恢复后自动重连"并拆掉会话；网络恢复后自动重连。
     以前 UDP 是无连接的，WiFi 掉了 socket 不会报错，界面会一直停在
     "已连接"，实际一个包都发不出去。
  2. 核心兜底：数据面连续 10 次发送失败即判定链路中断，退出本次会话并
     进入正常重连流程；发送失败日志改为限流打印（前 3 次 + 每 200 次），
     不再刷屏。失败日志带上 errno，便于区分"没路由"和"没权限"。
  3. 隧道建立时用 addDisallowedApplication 把本应用流量整体排除在 VPN
     之外，避免 0.0.0.0/0 把自己的 UDP 隧道报文吸进 TUN（表现为连上后
     一路"PPP: 发送帧失败（i/o error）"）。

v1.3.8
  1. SCCRQ 增加重传：按 2 秒 RTO 重发，最多 5 次。以前只发一次，
     第一个包在 NAT/防火墙上丢掉就只能等到超时。
  2. 超时提示带重传次数："已重传 0 次"说明服务端一个包都没回
     （多半是 use-ipsec=yes 把纯 L2TP 丢弃，或 UDP 1701 没放行）；
     "已重传 5 次"则说明链路在丢包。

v1.3.7
  1. 选 L2TP 时隐藏端口输入框：纯 L2TP 的端口由核心固定为 UDP 1701，
     自定义端口不生效，留着输入框只会误导。SSTP 仍可自定义（留空=443）。
  2. 连接时若协议是 L2TP，端口参数固定传 0，核心直接使用 1701，
     避免用户此前输入过的端口值被误用。

v1.3.6
  1. 中英文双语：跟随系统语言自动切换，涵盖界面全部标签、按钮、提示、
     连接状态、通知栏文案、日志级别标签，以及应用名（桌面图标下方显示
     "tunnel-client" 或 "tunnel-client"）。
     中文系统显示中文，其余语言显示英文，无需手动切换。
  2. 作者信息：界面底部显示"作者：szwwmz@gmail.com"，
     "版本说明"对话框标题也带作者。
  3. 恢复 L2TP（无 IPsec）：纯 L2TP 只走 UDP 1701，用的是普通 UDP
     socket，不需要原始套接字，Android 可用；带 IPsec（ESP 需原始
     套接字）仍不可用。选 L2TP 时自动隐藏"证书校验"，并提示服务器
     需关闭 IPsec（RouterOS：/interface l2tp-server server set
     use-ipsec=no）且放行 UDP 1701，该模式不加密。
     PPTP 仍不显示（GRE 47 需 root）。
  4. 调试日志正文来自核心（C 实现），仍为中文；界面与状态文案已双语。

v1.3.4
  1. 修复"连接成功但数据不通"。核心事件循环在进入循环前只取了一次 TUN 快照，
     而 Android 必须先完成 PPP 拿到地址，才能 Builder.establish() 建 TUN，
     也就是 TUN 在连接成功之后才挂接。这样一来整个会话 tun_snap.read 恒为空，
     上行一个包都不读；服务器收不到包也就没有下行，收发统计始终是 0。
     现在每轮循环重新取快照，Android 数据面正常转发。
  2. 桌面端（Windows/Linux）行为不变：它们的 TUN 在连接前就建好并传入核心，
     快照本来非空，改动只是把"取一次"变成"每轮取一次"，语义等价。

v1.3.3
  1. SSTP 支持跳过证书校验，并且默认就是跳过。RouterOS 等服务器多用自签
     证书，Android 上没有 OpenSSL 的默认 CA 路径，严格校验必然 tls error。
     界面新增"证书校验"下拉：
       跳过校验（自签证书，推荐）  默认；通道仍加密，但不验证服务器身份
       严格校验（需 ca.pem）      需把 CA 放到应用私有目录 ca.pem
  2. 修复"加载自定义 CA 失败: /data/user/0/.../files/ca.pem"。旧版无条件把
     这个从不存在的路径传给核心，核心加载失败就直接放弃握手。现在只有文件
     真存在且选了严格校验时才传。
  3. 协议下拉只保留 SSTP。PPTP 的数据面需要 GRE(IP 47) 原始套接字，
     L2TP/IPSec 的 ESP 同样需要原始套接字，未 root 的 Android 建不出来，
     留着只会拨号成功却发不出包，因此不再显示；配套的预共享密钥输入也移除。
  4. 想放自签 CA 时（一般不必）：
       adb push ca.pem /data/local/tmp/ca.pem
       再用 root 复制到 /data/data/com.example.vpnclient/files/ca.pem
     然后在界面把"证书校验"切到严格。

v1.3.2
  1. 修复"一点连接就闪退"。崩溃是
     MissingForegroundServiceTypeException：Android 14（targetSdk 34）要求
     前台服务声明具体类型，而清单没有 foregroundServiceType，
     startForeground 也没传 type，系统直接干掉进程。
     现在清单声明 specialUse + 子类型 vpn，
     startForeground 传入 FOREGROUND_SERVICE_TYPE_SPECIAL_USE
     （Android 14 以下走两参数版本）。
  2. 补 FOREGROUND_SERVICE_SPECIAL_USE 权限；补 POST_NOTIFICATIONS，
     Android 13+ 首次打开会询问通知权限，否则状态栏看不到连接状态
     （服务本身不受影响）。
  3. 若仍失败，日志区已能显示崩溃堆栈，点"复制日志"发出来即可。

v1.3.1
  1. 修复启动闪退。1.3.0 的新界面用到 kotlin-stdlib 里的
     Intrinsics / Lazy / ArrayDeque 等类，而构建脚本在 d8 阶段只喂了业务
     class，Kotlin 运行时没有进 dex，进程一启动就抛
     NoClassDefFoundError: kotlin/jvm/internal/Intrinsics。现在 d8 一并
     打包 kotlin-stdlib.jar（dex 从 58KB 变为 2.3MB，含 1039 个类）。
  2. 新增崩溃兜底：未捕获异常写 files/crash.log，下次打开时自动显示在
     日志区（读一次即删），没有电脑抓 logcat 也能把堆栈复制出来。
  3. 补上协议切换提示控件的初始化保护，避免极端时序下的空指针。
  4. 若仍闪退，请打开 app 后点"复制日志"发出来，或连电脑执行：
       adb logcat -s AndroidRuntime

v1.3.0
  1. 补齐应用图标（此前桌面显示系统默认安卓机器人）：提供 48~192px 各密度
     图标，并带 Android 8+ 自适应图标（前景+背景，圆形/方形桌面都能正常裁切）。
  2. 功能对齐 Windows 版：
       - 协议选择 PPTP / L2TP / SSTP，端口留空自动取该协议默认值
       - L2TP 的预共享密钥输入框（选中 L2TP 时才显示）
       - 接管全部流量 / 仅接管私有网段（10/8、172.16/12、192.168/16）
       - 接管 DNS（读取服务器下发的 DNS，未下发则不动本机 DNS）
       - 调试日志开关（默认关闭，与 Windows 的 ini debug 项同义）
       - 实时收发字节与包数统计
       - 日志区：阶段日志 + 清空 / 复制
       - 版本说明对话框
  3. 配置自动保存（服务器、端口、账号、密码、协议、路由选项、调试开关），
     下次打开直接恢复，不用重填。
  4. 单实例：launchMode=singleTask，重复点桌面图标只会回到已运行界面。
  5. 连接状态与通知栏文案跟随后端阶段（连接中/认证中/已连接/重连/失败）。

安装
----
1. 把 apk 传到手机（数据线 / adb install / 网盘），点击安装。
   首次会提示"未知来源"，允许即可。
2. 用 adb 安装更方便：
     adb install -r tunnel-client-android-1.4.0.apk

使用（与 MikroTik RouterOS 联调）
--------------------------------
1. 打开 app，先选协议（PPTP / L2TP / SSTP），再填写：
     服务器：RouterOS 的 IP 或域名
     端口  ：留空 = 协议默认（SSTP 443 / L2TP 1701 / PPTP 1723）
     用户名 / 密码：/ppp secret 里建的账号
     L2TP 时另需预共享密钥（/interface l2tp-server server print 里的 IPSec 密钥）
2. 按需要勾选"接管全部流量"（默认勾选）、"接管 DNS"（默认勾选）；
   排障时再勾"输出调试日志"，平时保持关闭，日志只留阶段节点。
2. 点"连接"，系统会弹出 VpnService 授权（首次），允许后开始拨号。
3. 状态依次是 connecting -> authenticating -> connected；
   连上后通知栏会常驻一条 VPN 状态通知。
4. 断开：在 app 内点"断开"，或直接点通知。

RouterOS 侧准备（SSTP）
----------------------
  /interface sstp-server server set enabled=yes default-profile=default
  /ppp secret add name=test password=test service=any
  # 自签证书时，客户端要允许忽略证书校验；app 内默认即为"忽略"。
  # 检查监听：/interface sstp-server server print

技术要点
--------
* 协议栈完整实现在 C 库（libvpncore.so）里：SSTP/TLS、PPP、LCP/PAP/CHAP/
  MSCHAPv2、IPCP；Java 层只负责 VpnService 建隧道与 UI。
* 隧道时序：先拨号拿到 IP，再 VpnService.Builder.establish()，然后把 fd 交给
  核心收发 IP 包（addAddress/addRoute/DNS 由 IPCP 结果决定）。
* 已做 VpnService.protect()：服务器连接绑定物理网卡，不会被自己的路由吞掉。
* 数据面不加密（L2TP 明文 / SSTP 的 PPP 载荷未启用 MPPE），仅适合实验环境。

常见问题
--------
* 连不上：确认 RouterOS 已 enable sstp-server，端口/防火墙放行。
* TLS 失败：RouterOS 证书是自签的，必须允许忽略校验（默认已忽略）。
* 认证失败：/ppp secret 的 service 要包含 sstp；用户名密码是否正确。
* 连接成功但上不了网：RouterOS 侧需要 NAT（/ip firewall nat add chain=srcnat
  action=masquerade out-interface=<外网口>），且 /ip dns 可用。
* 若系统提示"VPN 已断开"反复重连：查看 logcat：
     adb logcat -s vpncore VpnClientService

日志
----
app 内置日志区显示核心输出的阶段日志，可"清空日志"/"复制日志"；
勾选"输出调试日志"后才会出现逐包与协商细节（GRE 头、每帧 LCP 等）。
同一份日志也会输出到 logcat：

  adb logcat -s vpncore VpnClientService

卸载
----
直接卸载 app 即可，VpnService 隧道会随之关闭。
