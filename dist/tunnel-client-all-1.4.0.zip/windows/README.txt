tunnel-client（Windows 图形版） v1.4.0
================================
tunnel-client — 作者：wwm <szwwmz@gmail.com>

文件
----
  vpn-gui.exe   主程序（绿色免安装，无需 .NET / VC++ 运行时，已内嵌图标与版本信息）
  wintun.dll    虚拟网卡驱动（必须与 exe 同目录）
  app.ico       程序图标（做快捷方式时可选）
  README.txt    本说明

版本说明
--------
v1.4.0
  1. 界面支持中英双语，可随时切换：
       - 标题栏右上角「中文 / EN」胶囊，点一下立即切换；
       - 或右键托盘图标 →「语言 / Language」→ 中文 / English。
     选择写入 vpn-gui.ini（lang=zh|en），下次启动自动保持；默认中文。
     切换范围：窗口标题、标签、复选框、按钮、下拉项、状态/统计行、托盘菜单、
     托盘提示、各种提示框与版本说明。连接日志不随之切换（统一英文）。
  2. 连接日志与错误提示统一为英文，与命令行版 / Android 端一致，便于检索上报。
     日志级别标签改为 TRACE / DEBUG / INFO / WARN / ERROR，状态行前缀 [STATE]。
  3. 修复 L2TP/IPsec 长域名被静默截断：IKE 的 host 字段从 64 字节扩到 256 字节
     （与 VPN_HOST_LEN 一致）。此前域名超过 63 字符时 IKE 会拿掉尾的字符串去连，
     而报错信息里显示的又是完整域名，很难排查。
  4. 修复 CALL_CONNECTED 原地构造时 memcpy 源目标重叠（未定义行为）。
  5. 作者信息更新为 wwm <szwwmz@gmail.com>，界面底部与托盘版本说明同步显示。
  6. EXE 版本信息升到 1.4.0.0。

v1.3.0
  1. 三平台版本号统一为 1.3.0。本版 Windows 端功能与 1.2.3 相同，改动集中在
     Android 端：补齐应用图标、界面与功能对齐（协议选择、路由/DNS 开关、
     调试日志开关、日志区、配置保存、单实例）。
  2. EXE 版本信息升到 1.3.0.0。

v1.2.3
  1. 修复可以多开的问题。此前单实例判定放在 UAC 提权之后，而且提权重启出来
     的进程（带 --elevated）会跳过判定，等于从未生效：双击几次就开几个窗口，
     每个窗口各自去接管路由和网卡，互相打架。
     现在的顺序是：先按窗口类找已有实例 → 找到就恢复/前置并退出（不弹 UAC）；
     找不到才提权；真正跑起来的进程再用命名互斥体兜底，防止连点竞态。
  2. 再次启动时，最小化到托盘的窗口也会被拉回前台激活。
  3. EXE 版本信息升到 1.2.3.0。

v1.2.2
  1. 日志再精简：LCP 保活帧（Echo-Request / Echo-Reply / Discard-Request，
     code 9/10/11）降到调试级。客户端每 5 秒发一次 LCP Echo 保活，服务器逐条
     回 Echo-Reply，此前每条都打成"LCP: 收到 code=10"，长期挂着会持续刷屏。
  2. IPCP 的"服务器 Reject 选项"从警告降为调试：服务器不认某个选项后会用
     自己的提议重来，属于正常协商，不该报警告。
  3. 连接成功后日志稳定在十几行，静置时不再新增。需要看上述细节时把
     vpn-gui.ini 的 debug 改成 1。
  4. EXE 版本信息升到 1.2.2.0。

v1.2.1
  1. 修复 PPTP 连接一直停在 LCP 阶段：GRE 头从 0x2001 改为 0x3001，补上 4 字节
     序列号。此前对端（RouterOS / Windows 内置客户端都用 0x3001）按自己的头格式
     取字段，会把 FF03C021 当成序列号，后面的 PPP 帧整体错位，于是静默丢弃；
     现象是"包一直在发、对端一个都不回应"。现已与对端头格式完全一致。
  2. 日志默认精简：逐包诊断（GRE 头 hexdump、每帧 LCP、netsh 返回值）默认关闭，
     只保留连接各阶段的关键节点，一次连接从上百行降到二十行左右。
  3. 新增 debug 开关：vpn-gui.ini 中 debug=1 才输出逐包调试日志，默认 0。
     排障时改完重启程序即可，程序退出/连接时会自动把该项写回 ini。
  4. 日志区支持右键菜单：清除日志 / 复制全部。长日志不用再重启程序清空。
  5. 修正日志级别标签错位：此前 WARN 显示成[调试]、DEBUG 显示成[警告]，
     现在按 跟踪/调试/信息/警告/错误 正确对应。
  6. EXE 版本信息升到 1.2.1.0。

v1.2.0
  1. 新增"接管私有网段"：勾选后把 10.0.0.0/8、172.16.0.0/12、192.168.0.0/16 的流量
     指向 VPN。路由 metric=6000，远大于本机直连路由（通常 25），因此：
       - 已有相同前缀路由时，本机路由优先；
       - 本机更具体的网段（如 192.168.1.0/24）按最长前缀匹配，仍然走本机网卡。
     效果：可以访问 VPN 对端的 10.x / 172.16-31.x / 192.168.x 内网，同时不影响
     本机所在局域网的共享、打印机、路由器管理页等。
  2. 与"接管全部流量"可以叠加：全部流量优先，私有网段只在未接管全部流量时生效。
  3. 断开或退出时自动撤销已下发的路由（0.0.0.0/0 与三条私有网段），不再残留。
  4. 连接信息新增 routepriv 记忆项；托盘右键新增"版本说明"，也可点窗口底部版本行。
  5. EXE 版本信息升到 1.2.0.0。

v1.1.0
  1. 托盘常驻：点窗口右上角关闭 = 最小化到右下角托盘，程序继续运行；双击托盘图标
     恢复窗口，右键托盘图标有"显示/连接/断开/退出/版本说明"菜单。真正退出用托盘"退出"。
  2. 配置记忆：连接信息（协议/服务器/端口/账号/密码/证书/MTU/路由）自动保存到
     exe 同目录 vpn-gui.ini，下次打开自动带出（密码做了混淆，非明文）。删掉即恢复默认。
  3. 界面重绘：卡片式布局、状态圆点（灰=未连接 黄=连接/认证中 绿=已连接 红=失败）、
     深色日志区、悬停高亮的胶囊按钮，日志同步写入 exe 同目录 vpn-gui.log。
  4. 单实例：重复双击 exe 会激活已运行的窗口，不会开第二个。

DNS 接管
--------
连接成功后会把服务器下发的 DNS（通常是 VPN 网关地址，如 10.10.5.1）写到 VPNClient
网卡，并把该网卡度量压到 5，让 Windows 优先用这台 DNS 解析；否则系统仍会先问物理
网卡，内网域名（如 router.lan、nas.corp）解析不到。断开时自动清空该网卡的 DNS 并把
度量还原为自动，不会拖慢物理网卡的解析。

如果 VPN 对端的 DNS 只解析内网域名、不递归公网域名，可以关掉这个行为：在 vpn-gui.ini
里加一行 vpndns=0，重启程序即可。此时只用本机 DNS，内网域名请改用 IP 访问。

日志默认只输出关键节点。需要排障时，在 vpn-gui.ini 里把 debug 项改成 1 并重启程序，
即可看到逐包诊断（GRE 头、每帧 LCP、netsh 返回值等）；平时请保持 debug=0。
日志区右键可"清除日志"或"复制全部"。

验证是否生效（cmd，管理员）：
  netsh interface ipv4 show dnsservers "VPNClient"
  netsh interface ipv4 show interfaces | findstr /i vpnclient
  nslookup 内网域名 10.10.5.1

运行要求
--------
1. 直接双击 vpn-gui.exe 即可：程序检测到非管理员会自己弹 UAC 重启（创建虚拟网卡需要
   管理员权限）。若 UAC 被拒绝，会退化为"仅连通性验证"模式并给出提示。
2. wintun.dll 必须和 exe 放在同一目录，缺了它会退化成"仅连通性验证"模式
   （能连上、能认证、能拿到 IP，但不转发真实流量）。

与 MikroTik RouterOS 联调
-------------------------
1. RouterOS 侧先开服务：
     /interface sstp-server server set enabled=yes default-profile=default
     /ppp secret add name=test password=test service=any
   （L2TP: /interface l2tp-server server set enabled=yes，并在 /ppp secret 建账号）
2. 客户端填写：
     协议    SSTP（RouterOS 的 sstp-server，默认端口 443）
     服务器  RouterOS 的公网 IP / 域名
     端口    仅 SSTP 可填（默认 443）；选 L2TP/PPTP 时端口框自动禁用并固定为 1701/1723
     证书    RouterOS 自签证书 -> 选"忽略"；有正式证书 -> 选"校验"
     MTU     1400（PPPoE 线路建议 1400 或更低）
3. 点"连接"。日志区会依次出现（日志为英文）：
     [INFO] virtual adapter "VPNClient" created
     [STATE] connecting / authenticating / connected
     [INFO] adapter configured: 10.x.x.x/24 gateway 10.x.x.x
4. 路由接管（两个勾选框，可单独或同时使用）：
     [ ] 接管全部流量   0.0.0.0/0 -> VPN，全流量走隧道（会临时改变默认网关）
     [x] 接管私有网段   10/8、172.16/12、192.168/16 -> VPN，仅内网段走隧道
   "接管私有网段"的路由 metric=6000，比本机直连路由低，所以本机同网段资源
   （共享目录、打印机、光猫/路由器管理页）不会被劫持，只有本机路由表里不存在的
   私网地址才走 VPN。两个勾选互不冲突，全选时 0.0.0.0/0 覆盖其余。
   断开或退出程序会自动删除这些路由；若曾用旧版本残留，可手动清理：
     route delete 0.0.0.0 mask 0.0.0.0
     route delete 10.0.0.0 mask 255.0.0.0
     route delete 172.16.0.0 mask 255.240.0.0
     route delete 192.168.0.0 mask 255.255.0.0

支持的协议
----------
  SSTP   基于 TLS 1.2/1.3（需要服务端证书，客户端支持忽略校验）
  L2TP   明文 L2TPv2 承载 PPP（IPsec 需系统/路由器另行配置）
  PPTP   需要 GRE，Windows 客户端下通常不可用，仅保留接口

常见问题
--------
* "未能创建虚拟网卡"：wintun.dll 不在同目录，或没有以管理员身份运行。
* "创建 Wintun 适配器失败 (err=5)"：权限不足，用管理员运行。
* TLS 握手失败：RouterOS 证书不被信任 -> 选"忽略"；或服务端没开 sstp-server。
* 认证失败：/ppp secret 的 service 是否包含 sstp/l2tp；用户名密码是否匹配。
* 连上但打不开网页：确认勾了"接管全部流量"，或检查 RouterOS 的 NAT/路由。

日志
----
日志会同时显示在窗口里（最多保留最近的记录）。要抓完整日志排查协议问题时，
可在窗口日志区选中文本复制，或改用命令行版 vpn-cli --no-tun 观察更细的报文。

卸载
----
删除本目录即可。若残留虚拟网卡，可在"设备管理器 -> 网络适配器"里删除名为
VPNClient 的 Wintun 适配器，或在 PowerShell（管理员）里执行：
    pnputil /enum-devices /class Net

第三方组件与许可
----------------
本目录随包附带：
  THIRD-PARTY-NOTICES.txt       第三方组件声明（中文/English）
  LICENSE-wintun.txt            Wintun Prebuilt Binaries License（全文）
  LICENSE-Apache-2.0.txt        OpenSSL / NDK 使用的 Apache-2.0（全文）

  wintun.dll 为 Wintun 0.14.1 官方签名构建（amd64），版权归 WireGuard LLC，
  仅通过其公开 API 调用，未做任何修改；Wintun™ 是 WireGuard LLC 的商标，
  本项目与 WireGuard 项目无隶属关系、未获其背书。
  OpenSSL 3.0.2 静态链接进 vpn-gui.exe，按 Apache-2.0 分发。
  图标 app.ico 为自绘原创素材。
